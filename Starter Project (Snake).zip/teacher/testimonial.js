const testimonials = {
    'majid': [
        {
            id: 1,
            text: "Sir Majid's physics classes made me fall in love with the subject. His problem-solving approach is incredibly effective.",
            urduText: "سر مجید کی فزکس کی کلاسوں نے مجھے اس مضمون سے محبت کرنے پر مجبور کر دیا۔ ان کا مسئلہ حل کرنے کا طریقہ ناقابل یقین حد تک موثر ہے۔",
            author: {
                name: "Raza",
                title: "Engineering Student",
                image: "img/raza.jpg"
            }
        },
        {
            id: 2,
            text: "Thanks to Sir Majid's clear explanations, I finally understand calculus concepts that confused me for years.",
            urduText: "سر مجید کی واضح وضاحتوں کی بدولت، میں آخر کار کیلکولس کے ان تصورات کو سمجھ گیا جو سالوں سے مجھے الجھن میں ڈالتے تھے۔",
            author: {
                name: "Daniyal",
                title: "Mathematics Student",
                image: "img/Daniel.jpg"
            }
        },
        {
            id: 3,
            text: "The way Sir Majid connects theory with real-world applications makes learning physics exciting and relevant.",
            urduText: "سر مجید کا نظریات کو حقیقی دنیا کے مسائل سے جوڑنے کا طریقہ فزکس کو دلچسپ اور متعلقہ بنا دیتا ہے۔",
            author: {
                name: "Farhan",
                title: "Medical Student",
                image: "img/farhan.jpg"
            }
        },
        {
            id: 4,
            text: "Sir Majid's patience and dedication helped me overcome my fear of mathematics.",
            urduText: "سر مجید کے صبر اور لگن نے میری ریاضی کے خوف پر قابو پانے میں مدد کی۔",
            author: {
                name: "Sana",
                title: "College Student",
                image: "img/sana.jpg"
            }
        }
    ],
    'shahzad': [
        {
            id: 1,
            text: "Sir Shahzad's methodical approach to mathematics helped me develop a strong foundation in algebra and calculus.",
            urduText: "سر شہزاد کا ریاضی میں منظم طریقہ کار نے مجھے الجبرا اور کیلکولس میں مضبوط بنیاد بنانے میں مدد کی۔",
            author: {
                name: "Waqas",
                title: "Engineering Student",
                image: "img/waqas.jpg"
            }
        },
        {
            id: 2,
            text: "I went from failing math to scoring top grades thanks to Sir Shahzad's patient teaching style.",
            urduText: "سر شہزاد کے صبر آزما تدریسی انداز کی بدولت میں ریاضی میں فیل ہونے سے لے کر سب سے زیادہ نمبر حاصل کرنے تک پہنچ گیا۔",
            author: {
                name: "Farok",
                title: "College Student",
                image: "img/farok.jpg"
            }
        },
        {
            id: 3,
            text: "Sir Shahzad's problem-solving techniques are invaluable for competitive exam preparation.",
            urduText: "سر شہزاد کے مسئلہ حل کرنے کے طریقے مقابلہ جاتی امتحانات کی تیاری کے لیے ناقابل قیمت ہیں۔",
            author: {
                name: "Ali",
                title: "Competitive Exam Aspirant",
                image: "img/ali.jpg"
            }
        },
        {
            id: 4,
            text: "The way Sir Shahzad breaks down complex problems into simple steps is remarkable.",
            urduText: "سر شہزاد کا پیچیدہ مسائل کو آسان مراحل میں تقسیم کرنے کا طریقہ قابل تعریف ہے۔",
            author: {
                name: "Hina",
                title: "University Student",
                image: "img/hina.jpg"
            }
        }
    ],
    'shahzad-iqbal': [
        {
            id: 1,
            text: "Sir Shahzad's interdisciplinary approach helped me see the connections between computer science and chemistry in ways I never imagined.",
            urduText: "سر شہزاد کا بین الشعبہ جاتی طریقہ کار نے مجھے کمپیوٹر سائنس اور کیمسٹری کے درمیان تعلق کو ایسے طریقے سے دیکھنے میں مدد دی جس کا میں نے کبھی تصور بھی نہیں کیا تھا۔",
            author: {
                name: "Sikandar",
                title: "Computer Science Student",
                image: "img/sikandar.jpg"
            }
        },
        {
            id: 2,
            text: "The way sir connects programming concepts to chemical processes is revolutionary. I went from struggling with both subjects to excelling in computational chemistry!",
            urduText: "سر کا طریقہ کہ وہ پروگرامنگ کے تصورات کو کیمیائی عمل سے جوڑتے ہیں، انقلابی ہے۔ میں دونوں مضامین میں مشکلات کا شکار ہونے سے کمپیوٹیشنل کیمسٹری میں مہارت حاصل کرنے تک پہنچ گیا ہوں!",
            author: {
                name: "Raza",
                title: "Chemistry Major",
                image: "img/raza.jpg"
            }
        },
        {
            id: 3,
            text: "Sir Shahzad's project-based approach gave me practical skills that helped me secure a research position.",
            urduText: "سر شہزاد کا منصوبہ پر مبنی طریقہ کار نے مجھے عملی مہارتیں دیں جنہوں نے مجھے ایک تحقیقی عہدہ حاصل کرنے میں مدد کی۔",
            author: {
                name: "Fatima",
                title: "Research Assistant",
                image: "img/fatima.jpg"
            }
        },
        {
            id: 4,
            text: "The computational chemistry techniques I learned from Sir Shahzad have become essential in my PhD research.",
            urduText: "سر شہزاد سے سیکھی گئی کمپیوٹیشنل کیمسٹری کی تکنیک میرے پی ایچ ڈی تحقیق کا لازمی حصہ بن گئی ہیں۔",
            author: {
                name: "Bilal",
                title: "PhD Researcher",
                image: "img/bilal.jpg"
            }
        }
    ],
    'monir-shamsi': [
        {
            id: 1,
            text: "Sir Monir's literature classes transformed my understanding of both English and Urdu poetry and prose.",
            urduText: "سر منیر کی ادب کی کلاسوں نے انگریزی اور اردو دونوں زبانوں کی شاعری اور نثر کے بارے میں میری سمجھ کو تبدیل کر دیا۔",
            author: {
                name: "Hassan",
                title: "Literature Student",
                image: "img/Hassan.jpg"
            }
        },
        {
            id: 2,
            text: "Thanks to Sir Monir, I improved my academic writing skills in both languages and secured top marks in my exams.",
            urduText: "سر منیر کی بدولت، میں نے دونوں زبانوں میں اپنی علمی تحریری مہارت کو بہتر بنایا اور اپنے امتحانات میں اعلیٰ نمبر حاصل کیے۔",
            author: {
                name: "Daniyal",
                title: "University Student",
                image: "img/Daniel.jpg"
            }
        },
        {
            id: 3,
            text: "Sir Monir's analysis of classical Urdu poetry gave me a new appreciation for our literary heritage.",
            urduText: "سر منیر کا کلاسیکی اردو شاعری کا تجزیہ نے مجھے ہماری ادبی وراثت کے لیے نئی تعریف پیدا کر دی۔",
            author: {
                name: "Ayesha",
                title: "Literature Enthusiast",
                image: "img/ayesha.jpg"
            }
        },
        {
            id: 4,
            text: "The creative writing techniques I learned from Sir Monir helped me publish my first short story collection.",
            urduText: "سر منیر سے سیکھی گئی تخلیقی تحریر کی تکنیکوں نے میری پہلی افسانوی کہانیوں کی کتاب شائع کرنے میں مدد کی۔",
            author: {
                name: "Kamran",
                title: "Author",
                image: "img/kamran.jpg"
            }
        }
    ],
    'adeel-shamsi': [
        {
            id: 1,
            text: "Sir Adeel's computational biology classes showed me how powerful programming can be in biological research.",
            urduText: "سر عادل کی کمپیوٹیشنل بائیولوجی کی کلاسوں نے مجھے دکھایا کہ حیاتیاتی تحقیق میں پروگرامنگ کتنی طاقتور ہو سکتی ہے۔",
            author: {
                name: "Sikandar",
                title: "Biology Student",
                image: "img/sikandar.jpg"
            }
        },
        {
            id: 2,
            text: "The bioinformatics projects we did in Sir Adeel's class helped me secure a research internship at a leading lab.",
            urduText: "سر عادل کی کلاس میں کیے گئے بائیو انفارمیٹکس کے منصوبوں نے مجھے ایک معتبر لیب میں تحقیقی انٹرنشپ حاصل کرنے میں مدد کی۔",
            author: {
                name: "Raza",
                title: "Research Intern",
                image: "img/raza.jpg"
            }
        },
        {
            id: 3,
            text: "Sir Adeel's teaching made complex biological concepts accessible through computational approaches.",
            urduText: "سر عادل کی تدریس نے کمپیوٹیشنل طریقوں کے ذریعے پیچیدہ حیاتیاتی تصورات کو قابل رسائی بنا دیا۔",
            author: {
                name: "Zainab",
                title: "Biotechnology Student",
                image: "img/zainab.jpg"
            }
        },
        {
            id: 4,
            text: "The Python for Biology course by Sir Adeel gave me skills that are directly applicable to my PhD research.",
            urduText: "سر عادل کی 'بائیولوجی کے لیے پائتھون' کورس نے مجھے ایسی مہارتیں دیں جو براہ راست میرے پی ایچ ڈی تحقیق پر لاگو ہوتی ہیں۔",
            author: {
                name: "Usman",
                title: "PhD Candidate",
                image: "img/usman.jpg"
            }
        }
    ]
};